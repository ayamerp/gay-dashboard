﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard
{
    public partial class frmCalender : Form
    {
        public frmCalender()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series["Pay Gap"].Points.AddXY("$15,000 or higher", "2");
            chart1.Series["Pay Gap"].Points.AddXY("$12,500 to 14,999", "8");
            chart1.Series["Pay Gap"].Points.AddXY("$10,000 to $12,999", "23");
            chart1.Series["Pay Gap"].Points.AddXY("$4,000 to $9,999", "17");
        }
    }
}
