﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard
{
    public partial class frmAnalytics : Form
    {
        public frmAnalytics()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //chart 1
            chart1.Series["Male"].Points.AddXY("2011", 144833.0);
            chart1.Series["Male"].Points.AddXY("2011", 136574.0);
            chart1.Series["Male"].Points.AddXY("2012", 125994.0);
            chart1.Series["Male"].Points.AddXY("2012", 129302.0);
            chart1.Series["Male"].Points.AddXY("2012", 147973.0);
            chart1.Series["Male"].Points.AddXY("2012", 138855.0);
            chart1.Series["Male"].Points.AddXY("2013", 127699.0);
            chart1.Series["Male"].Points.AddXY("2013", 131456.0);
            chart1.Series["Male"].Points.AddXY("2013", 149710.0);
            chart1.Series["Male"].Points.AddXY("2013", 141050.0);
            chart1.Series["Male"].Points.AddXY("2014", 128998.0);
            chart1.Series["Male"].Points.AddXY("2014", 133602.0);
            chart1.Series["Male"].Points.AddXY("2014", 152235.0);
            chart1.Series["Male"].Points.AddXY("2014", 142579.0);
            chart1.Series["Male"].Points.AddXY("2015", 131222.0);
            chart1.Series["Male"].Points.AddXY("2015", 134593.0);
            chart1.Series["Male"].Points.AddXY("2015", 152408.0);
            chart1.Series["Male"].Points.AddXY("2015", 141890.0);
            chart1.Series["Male"].Points.AddXY("2016", 128939.0);
            chart1.Series["Male"].Points.AddXY("2016", 131890.0);


            chart1.Series["Female"].Points.AddXY("2011", 117360.0);
            chart1.Series["Female"].Points.AddXY("2011", 111143.0);
            chart1.Series["Female"].Points.AddXY("2012", 107064.0);
            chart1.Series["Female"].Points.AddXY("2012", 108414.0);
            chart1.Series["Female"].Points.AddXY("2012", 119334.0);
            chart1.Series["Female"].Points.AddXY("2012", 112837.0);
            chart1.Series["Female"].Points.AddXY("2013", 108195.0);
            chart1.Series["Female"].Points.AddXY("2013", 109397.0);
            chart1.Series["Female"].Points.AddXY("2013", 120545.0);
            chart1.Series["Female"].Points.AddXY("2013", 114400.0);
            chart1.Series["Female"].Points.AddXY("2014", 108268.0);
            chart1.Series["Female"].Points.AddXY("2014", 109760.0);
            chart1.Series["Female"].Points.AddXY("2014", 121282.0);
            chart1.Series["Female"].Points.AddXY("2014", 114484.0);
            chart1.Series["Female"].Points.AddXY("2015", 110046.0);
            chart1.Series["Female"].Points.AddXY("2015", 111022.0);
            chart1.Series["Female"].Points.AddXY("2015", 123108.0);
            chart1.Series["Female"].Points.AddXY("2015", 115719.0);
            chart1.Series["Female"].Points.AddXY("2016", 110202.0);
            chart1.Series["Female"].Points.AddXY("2016", 111592.0);
            //chart 1 end

            //chart 2
            chart2.Series["Men"].Points.AddXY("Chief executives", 932743);
            chart2.Series["Women"].Points.AddXY("Chief executives", 335274);

            chart2.Series["Men"].Points.AddXY("General and operations managers", 685078);
            chart2.Series["Women"].Points.AddXY("General and operations managers", 341720);

            chart2.Series["Men"].Points.AddXY("Legislators", 7266);
            chart2.Series["Women"].Points.AddXY("Legislators", 4812);

            chart2.Series["Men"].Points.AddXY("Advertising and promotions managers", 20939);
            chart2.Series["Women"].Points.AddXY("Advertising and promotions managers", 27023);

            chart2.Series["Men"].Points.AddXY("Marketing managers", 185926);
            chart2.Series["Women"].Points.AddXY("Marketing managers", 276885);

            chart2.Series["Men"].Points.AddXY("Sales managers", 334121);
            chart2.Series["Women"].Points.AddXY("Sales managers", 160616);

            chart2.Series["Men"].Points.AddXY("Public relations and fundraising managers", 28038);
            chart2.Series["Women"].Points.AddXY("Public relations and fundraising managers", 56216);

            chart2.Series["Men"].Points.AddXY("Administrative services managers", 17489);
            chart2.Series["Women"].Points.AddXY("Administrative services managers", 39148);

            chart2.Series["Men"].Points.AddXY("Facilities managers", 90355);
            chart2.Series["Women"].Points.AddXY("Facilities managers", 18699);

            chart2.Series["Men"].Points.AddXY("Computer and information systems managers", 437646);
            chart2.Series["Women"].Points.AddXY("Computer and information systems managers", 176524);

            chart2.Series["Men"].Points.AddXY("Financial managers", 533586);
            chart2.Series["Women"].Points.AddXY("Financial managers", 673688);

            chart2.Series["Men"].Points.AddXY("Compensation and benefits managers", 4326);
            chart2.Series["Women"].Points.AddXY("Compensation and benefits managers", 13337);

            chart2.Series["Men"].Points.AddXY("Human resources managers", 59647);
            chart2.Series["Women"].Points.AddXY("Human resources managers", 180262);

            chart2.Series["Men"].Points.AddXY("Training and development managers", 23477);
            chart2.Series["Women"].Points.AddXY("Training and development managers", 27928);

            chart2.Series["Men"].Points.AddXY("Industrial production managers", 197946);
            chart2.Series["Women"].Points.AddXY("Industrial production managers", 57438);

            chart2.Series["Men"].Points.AddXY("Purchasing managers", 100815);
            chart2.Series["Women"].Points.AddXY("Purchasing managers", 98346);

            chart2.Series["Men"].Points.AddXY("Transportation, storage, and distribution managers", 204652);
            chart2.Series["Women"].Points.AddXY("Transportation, storage, and distribution managers", 50084);

            chart2.Series["Men"].Points.AddXY("Farmers, ranchers, and other agricultural managers", 411859);
            chart2.Series["Women"].Points.AddXY("Farmers, ranchers, and other agricultural managers", 56949);

            chart2.Series["Men"].Points.AddXY("Construction managers", 716687);
            chart2.Series["Women"].Points.AddXY("Construction managers", 62880);

            chart2.Series["Men"].Points.AddXY("Education and childcare administrators", 285342);
            chart2.Series["Women"].Points.AddXY("Education and childcare administrators", 516036);

            chart2.Series["Men"].Points.AddXY("Architectural and engineering managers", 149081);
            chart2.Series["Women"].Points.AddXY("Architectural and engineering managers", 18583);

            chart2.Series["Men"].Points.AddXY("Food service managers", 432632);
            chart2.Series["Women"].Points.AddXY("Food service managers", 398667);

            chart2.Series["Men"].Points.AddXY("Funeral home managers", 4520);
            chart2.Series["Women"].Points.AddXY("Funeral home managers", 2629);

            chart2.Series["Men"].Points.AddXY("Entertainment and recreation managers", 19178);
            chart2.Series["Women"].Points.AddXY("Entertainment and recreation managers", 12074);

            chart2.Series["Men"].Points.AddXY("Lodging managers", 60479);
            chart2.Series["Women"].Points.AddXY("Lodging managers", 63351);

            chart2.Series["Men"].Points.AddXY("Medical and health services managers", 172451);
            chart2.Series["Women"].Points.AddXY("Medical and health services managers", 439510);

            chart2.Series["Men"].Points.AddXY("Natural sciences managers", 6544);
            chart2.Series["Women"].Points.AddXY("Natural sciences managers", 9038);

            chart2.Series["Men"].Points.AddXY("Postmasters and mail superintendents", 12918);
            chart2.Series["Women"].Points.AddXY("Postmasters and mail superintendents", 12989);

            chart2.Series["Men"].Points.AddXY("Property, real estate, and community association", 223510);
            chart2.Series["Women"].Points.AddXY("Property, real estate, and community association", 246039);

            chart2.Series["Men"].Points.AddXY("Social and community service managers", 104765);
            chart2.Series["Women"].Points.AddXY("Social and community service managers", 242724);

            chart2.Series["Men"].Points.AddXY("Emergency management directors", 7815);
            chart2.Series["Women"].Points.AddXY("Emergency management directors", 4617);

            chart2.Series["Men"].Points.AddXY("Personal service managers, all other", 458);
            chart2.Series["Women"].Points.AddXY("Personal service managers, all other", 1319);

            chart2.Series["Men"].Points.AddXY("Managers, all other", 2428328);
            chart2.Series["Women"].Points.AddXY("Managers, all other", 1341712);

        }

    }
}
